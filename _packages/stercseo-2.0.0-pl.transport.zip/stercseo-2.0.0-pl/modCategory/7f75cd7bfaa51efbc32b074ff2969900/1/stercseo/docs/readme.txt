--------------------
SEOTab
--------------------
Version: 2.0.0-pl
Author: Sterc <modx@sterc.nl>

License: GNU GPLv2
--------------------

More info : https://github.com/Sterc/SEOTab