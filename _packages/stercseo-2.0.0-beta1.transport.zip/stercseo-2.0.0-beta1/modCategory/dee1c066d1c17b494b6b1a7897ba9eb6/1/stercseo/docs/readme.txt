--------------------
SEOTab
--------------------
Version: 1.2.2-pl
Author: Sterc <modx@sterc.nl>

License: GNU GPLv2
--------------------

More info : http://www.stercx.com/modx-extras/