<?php
/**
 * @package stercseo
 */
class seoUrl extends xPDOSimpleObject {}
?>
